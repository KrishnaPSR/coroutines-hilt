package com.deividasstr.ui.features.sweetdetails

interface NavigationCallback {
    fun onNavigate()
}