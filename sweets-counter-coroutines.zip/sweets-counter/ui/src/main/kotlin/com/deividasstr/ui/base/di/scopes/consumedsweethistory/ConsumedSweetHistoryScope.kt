package com.deividasstr.ui.base.di.scopes.consumedsweethistory

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class ConsumedSweetHistoryScope