package com.deividasstr.ui.features.consumedsweetdata.models

data class UpperPeriodModel(val rangeText: String, val consumedBarData: ConsumedBarData)