package com.deividasstr.ui.base.framework

data class FabSetter(val srcRes: Int, val onClick: () -> Unit)