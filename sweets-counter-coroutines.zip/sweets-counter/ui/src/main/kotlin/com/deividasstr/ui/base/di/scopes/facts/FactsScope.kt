package com.deividasstr.ui.base.di.scopes.facts

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class FactsScope