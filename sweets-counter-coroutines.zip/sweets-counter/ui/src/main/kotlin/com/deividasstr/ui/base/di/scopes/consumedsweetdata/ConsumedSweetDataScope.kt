package com.deividasstr.ui.base.di.scopes.consumedsweetdata

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class ConsumedSweetDataScope