package com.deividasstr.ui.features.consumedsweetdata.utils

object Consts {
    const val INFINITY_IMITATION = 100
    const val FIRST_ITEM = INFINITY_IMITATION / 2
}