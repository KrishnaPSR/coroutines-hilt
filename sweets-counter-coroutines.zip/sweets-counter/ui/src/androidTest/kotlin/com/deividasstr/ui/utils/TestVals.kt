package com.deividasstr.ui.utils

class TestVals {

    companion object {
        var mockUrl: String = "https://hello.world.com"
    }
}