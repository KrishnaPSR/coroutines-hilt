package com.deividasstr.ui.features.sweetdetails

import org.junit.After
import org.junit.Before

class SweetDetailsViewModelTest {

    @Before
    fun setUp() {
    }

    @After
    fun tearDown() {
    }
}