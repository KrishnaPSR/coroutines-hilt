package com.deividasstr.domain.entities.models

data class Fact(val id: Long, val text: String)