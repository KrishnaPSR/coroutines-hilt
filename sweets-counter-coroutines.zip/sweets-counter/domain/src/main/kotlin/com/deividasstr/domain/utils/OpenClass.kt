package com.deividasstr.domain.utils

@Target(AnnotationTarget.CLASS)
annotation class OpenClass