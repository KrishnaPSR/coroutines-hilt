package com.deividasstr.data.utils

class StringResException(val messageStringRes: Int) : Throwable()