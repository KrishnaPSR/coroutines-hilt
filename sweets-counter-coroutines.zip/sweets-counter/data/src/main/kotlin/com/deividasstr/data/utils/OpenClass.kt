package com.deividasstr.data.utils

@Target(AnnotationTarget.ANNOTATION_CLASS)
annotation class OpenClass