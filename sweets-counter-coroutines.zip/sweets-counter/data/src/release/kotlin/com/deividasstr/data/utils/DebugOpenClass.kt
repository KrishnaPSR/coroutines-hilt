package com.deividasstr.data.utils

@Target(AnnotationTarget.CLASS)
annotation class DebugOpenClass