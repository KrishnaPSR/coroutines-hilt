package com.deividasstr.data.utils

@OpenClass
@Target(AnnotationTarget.CLASS)
annotation class DebugOpenClass